#include <SFML/Graphics.hpp>

#include <windows.h>
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main()
{

    HKEY RegKey;

    sf::RenderWindow window(sf::VideoMode(500, 510), "Button's Sims 3 Expansion Manager v0.2");

    sf::Texture background;
    sf::Sprite backgroundImage;

    (!background.loadFromFile("resources/background.png"));

    backgroundImage.setTexture(background);
    backgroundImage.setScale(1, 1);

    sf::Texture e1;
    sf::Sprite e1Image;

    sf::Texture e2;
    sf::Sprite e2Image;

    sf::Texture e3;
    sf::Sprite e3Image;

    sf::Texture e4;
    sf::Sprite e4Image;

    sf::Texture e5;
    sf::Sprite e5Image;

    sf::Texture e6;
    sf::Sprite e6Image;

    sf::Texture e7;
    sf::Sprite e7Image;

    sf::Texture e8;
    sf::Sprite e8Image;

    sf::Texture e9;
    sf::Sprite e9Image;

    sf::Texture e10;
    sf::Sprite e10Image;

    sf::Texture e11;
    sf::Sprite e11Image;

    sf::Texture e12;
    sf::Sprite e12Image;

    sf::Texture e13;
    sf::Sprite e13Image;

    sf::Texture e14;
    sf::Sprite e14Image;

    sf::Texture e15;
    sf::Sprite e15Image;

    sf::Texture e16;
    sf::Sprite e16Image;

    sf::Texture e17;
    sf::Sprite e17Image;

    if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Ambitions\\", &RegKey) == ERROR_SUCCESS)
    {
        (!e1.loadFromFile("resources/e1.png", sf::IntRect(194, 0, 194, 30)));
    }
    else
    {
        (!e1.loadFromFile("resources/e1.png", sf::IntRect(0, 0, 194, 30)));
    }

    if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Generations\\", &RegKey) == ERROR_SUCCESS)
    {
        (!e2.loadFromFile("resources/e2.png", sf::IntRect(194, 0, 194, 30)));
    }
    else
    {
        (!e2.loadFromFile("resources/e2.png", sf::IntRect(0, 0, 194, 30)));
    }

    if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 High-End Loft Stuff\\", &RegKey) == ERROR_SUCCESS)
    {
        (!e3.loadFromFile("resources/e3.png", sf::IntRect(194, 0, 194, 30)));
    }
    else
    {
        (!e3.loadFromFile("resources/e3.png", sf::IntRect(0, 0, 194, 30)));
    }

    if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Island Paradise\\", &RegKey) == ERROR_SUCCESS)
    {
        (!e4.loadFromFile("resources/e4.png", sf::IntRect(194, 0, 194, 30)));
    }
    else
    {
        (!e4.loadFromFile("resources/e4.png", sf::IntRect(0, 0, 194, 30)));
    }

    if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Late Night\\", &RegKey) == ERROR_SUCCESS)
    {
        (!e5.loadFromFile("resources/e5.png", sf::IntRect(194, 0, 194, 30)));
    }
    else
    {
        (!e5.loadFromFile("resources/e5.png", sf::IntRect(0, 0, 194, 30)));
    }

    if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Master Suite Stuff\\", &RegKey) == ERROR_SUCCESS)
    {
        (!e6.loadFromFile("resources/e6.png", sf::IntRect(194, 0, 194, 30)));
    }
    else
    {
        (!e6.loadFromFile("resources/e6.png", sf::IntRect(0, 0, 194, 30)));
    }

    if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Outdoor Living Stuff\\", &RegKey) == ERROR_SUCCESS)
    {
        (!e7.loadFromFile("resources/e7.png", sf::IntRect(194, 0, 194, 30)));
    }
    else
    {
        (!e7.loadFromFile("resources/e7.png", sf::IntRect(0, 0, 194, 30)));
    }

    if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Pets\\", &RegKey) == ERROR_SUCCESS)
    {
        (!e8.loadFromFile("resources/e8.png", sf::IntRect(194, 0, 194, 30)));
    }
    else
    {
        (!e8.loadFromFile("resources/e8.png", sf::IntRect(0, 0, 194, 30)));
    }

    if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Seasons\\", &RegKey) == ERROR_SUCCESS)
    {
        (!e9.loadFromFile("resources/e9.png", sf::IntRect(194, 0, 194, 30)));
    }
    else
    {
        (!e9.loadFromFile("resources/e9.png", sf::IntRect(0, 0, 194, 30)));
    }

    if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Showtime\\", &RegKey) == ERROR_SUCCESS)
    {
        (!e10.loadFromFile("resources/e10.png", sf::IntRect(194, 0, 194, 30)));
    }
    else
    {
        (!e10.loadFromFile("resources/e10.png", sf::IntRect(0, 0, 194, 30)));
    }

    if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Supernatural\\", &RegKey) == ERROR_SUCCESS)
    {
        (!e11.loadFromFile("resources/e11.png", sf::IntRect(194, 0, 194, 30)));
    }
    else
    {
        (!e11.loadFromFile("resources/e11.png", sf::IntRect(0, 0, 194, 30)));
    }

    if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Town Life Stuff\\", &RegKey) == ERROR_SUCCESS)
    {
        (!e12.loadFromFile("resources/e12.png", sf::IntRect(194, 0, 194, 30)));
    }
    else
    {
        (!e12.loadFromFile("resources/e12.png", sf::IntRect(0, 0, 194, 30)));
    }

    if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 University Life\\", &RegKey) == ERROR_SUCCESS)
    {
        (!e13.loadFromFile("resources/e13.png", sf::IntRect(194, 0, 194, 30)));
    }
    else
    {
        (!e13.loadFromFile("resources/e13.png", sf::IntRect(0, 0, 194, 30)));
    }

    if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 World Adventures\\", &RegKey) == ERROR_SUCCESS)
    {
        (!e14.loadFromFile("resources/e14.png", sf::IntRect(194, 0, 194, 30)));
    }
    else
    {
        (!e14.loadFromFile("resources/e14.png", sf::IntRect(0, 0, 194, 30)));
    }

    if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 70s 80s & 90s Stuff\\", &RegKey) == ERROR_SUCCESS)
    {
        (!e15.loadFromFile("resources/e15.png", sf::IntRect(194, 0, 194, 30)));
    }
    else
    {
        (!e15.loadFromFile("resources/e15.png", sf::IntRect(0, 0, 194, 30)));
    }

    (!e16.loadFromFile("resources/e16.png"));

    (!e17.loadFromFile("resources/e17.png"));

    e1Image.setPosition(-0, 0);
    e1Image.setTexture(e1);

    e2Image.setPosition(-0, 30);
    e2Image.setTexture(e2);

    e3Image.setPosition(-0, 60);
    e3Image.setTexture(e3);

    e4Image.setPosition(-0, 90);
    e4Image.setTexture(e4);

    e5Image.setPosition(-0, 120);
    e5Image.setTexture(e5);

    e6Image.setPosition(-0, 150);
    e6Image.setTexture(e6);

    e7Image.setPosition(-0, 180);
    e7Image.setTexture(e7);

    e8Image.setPosition(-0, 210);
    e8Image.setTexture(e8);

    e9Image.setPosition(-0, 240);
    e9Image.setTexture(e9);

    e10Image.setPosition(-0, 270);
    e10Image.setTexture(e10);

    e11Image.setPosition(-0, 300);
    e11Image.setTexture(e11);

    e12Image.setPosition(-0, 330);
    e12Image.setTexture(e12);

    e13Image.setPosition(-0, 360);
    e13Image.setTexture(e13);

    e14Image.setPosition(-0, 390);
    e14Image.setTexture(e14);

    e15Image.setPosition(-0, 420);
    e15Image.setTexture(e15);

    e16Image.setPosition(-0, 450);
    e16Image.setTexture(e16);

    e17Image.setPosition(-0, 480);
    e17Image.setTexture(e17);

    float e1Width = e1Image.getLocalBounds().width;
    float e1Height = e1Image.getLocalBounds().height;

    float e2Width = e2Image.getLocalBounds().width;
    float e2Height = e2Image.getLocalBounds().height;

    float e3Width = e3Image.getLocalBounds().width;
    float e3Height = e3Image.getLocalBounds().height;

    float e4Width = e4Image.getLocalBounds().width;
    float e4Height = e4Image.getLocalBounds().height;

    float e5Width = e5Image.getLocalBounds().width;
    float e5Height = e5Image.getLocalBounds().height;

    float e6Width = e6Image.getLocalBounds().width;
    float e6Height = e6Image.getLocalBounds().height;

    float e7Width = e7Image.getLocalBounds().width;
    float e7Height = e7Image.getLocalBounds().height;

    float e8Width = e8Image.getLocalBounds().width;
    float e8Height = e8Image.getLocalBounds().height;

    float e9Width = e9Image.getLocalBounds().width;
    float e9Height = e9Image.getLocalBounds().height;

    float e10Width = e10Image.getLocalBounds().width;
    float e10Height = e10Image.getLocalBounds().height;

    float e11Width = e11Image.getLocalBounds().width;
    float e11Height = e11Image.getLocalBounds().height;

    float e12Width = e12Image.getLocalBounds().width;
    float e12Height = e12Image.getLocalBounds().height;

    float e13Width = e13Image.getLocalBounds().width;
    float e13Height = e13Image.getLocalBounds().height;

    float e14Width = e14Image.getLocalBounds().width;
    float e14Height = e14Image.getLocalBounds().height;

    float e15Width = e15Image.getLocalBounds().width;
    float e15Height = e15Image.getLocalBounds().height;

    float e16Width = e16Image.getLocalBounds().width;
    float e16Height = e16Image.getLocalBounds().height;

    float e17Width = e17Image.getLocalBounds().width;
    float e17Height = e17Image.getLocalBounds().height;

    while (window.isOpen())
    {

        sf::Event event;
        while (window.pollEvent(event))
        {

            switch (event.type)
            {

                case sf::Event::Closed:
                    window.close();
                break;

                window.clear();

                case sf::Event::MouseMoved:
                {
                    sf::Vector2i mousePos = sf::Mouse::getPosition(window);
                    sf::Vector2f mousePosF (static_cast<float>(mousePos.x), static_cast<float>(mousePos.y));

                    if(e1Image.getGlobalBounds().contains(mousePosF))
                    {
                        e1Image.setColor(sf::Color(200, 255, 255));
                    }
                    else
                    {
                        e1Image.setColor(sf::Color(255, 255, 255));
                    }

                    if(e2Image.getGlobalBounds().contains(mousePosF))
                    {
                            e2Image.setColor(sf::Color(200, 255, 255));
                    }
                    else
                    {
                            e2Image.setColor(sf::Color(255, 255, 255));
                    }

                    if(e3Image.getGlobalBounds().contains(mousePosF))
                    {
                        e3Image.setColor(sf::Color(200, 255, 255));
                    }
                    else
                    {
                        e3Image.setColor(sf::Color(255, 255, 255));
                    }

                    if(e4Image.getGlobalBounds().contains(mousePosF))
                    {
                        e4Image.setColor(sf::Color(200, 255, 255));
                    }
                    else
                    {
                        e4Image.setColor(sf::Color(255, 255, 255));
                    }

                    if(e5Image.getGlobalBounds().contains(mousePosF))
                    {
                        e5Image.setColor(sf::Color(200, 255, 255));
                    }
                    else
                    {
                        e5Image.setColor(sf::Color(255, 255, 255));
                    }

                    if(e6Image.getGlobalBounds().contains(mousePosF))
                    {
                        e6Image.setColor(sf::Color(200, 255, 255));
                    }
                    else
                    {
                        e6Image.setColor(sf::Color(255, 255, 255));
                    }

                    if(e7Image.getGlobalBounds().contains(mousePosF))
                    {
                        e7Image.setColor(sf::Color(200, 255, 255));
                    }
                    else
                    {
                        e7Image.setColor(sf::Color(255, 255, 255));
                    }

                    if(e8Image.getGlobalBounds().contains(mousePosF))
                    {
                        e8Image.setColor(sf::Color(200, 255, 255));
                    }
                    else
                    {
                        e8Image.setColor(sf::Color(255, 255, 255));
                    }

                    if(e9Image.getGlobalBounds().contains(mousePosF))
                    {
                        e9Image.setColor(sf::Color(200, 255, 255));
                    }
                    else
                    {
                        e9Image.setColor(sf::Color(255, 255, 255));
                    }

                    if(e10Image.getGlobalBounds().contains(mousePosF))
                    {
                        e10Image.setColor(sf::Color(200, 255, 255));
                    }
                    else
                    {
                        e10Image.setColor(sf::Color(255, 255, 255));
                    }

                    if(e11Image.getGlobalBounds().contains(mousePosF))
                    {
                        e11Image.setColor(sf::Color(200, 255, 255));
                    }
                    else
                    {
                        e11Image.setColor(sf::Color(255, 255, 255));
                    }

                    if(e12Image.getGlobalBounds().contains(mousePosF))
                    {
                        e12Image.setColor(sf::Color(200, 255, 255));
                    }
                    else
                    {
                        e12Image.setColor(sf::Color(255, 255, 255));
                    }

                    if(e13Image.getGlobalBounds().contains(mousePosF))
                    {
                        e13Image.setColor(sf::Color(200, 255, 255));
                    }
                    else
                    {
                        e13Image.setColor(sf::Color(255, 255, 255));
                    }

                    if(e14Image.getGlobalBounds().contains(mousePosF))
                    {
                        e14Image.setColor(sf::Color(200, 255, 255));
                    }
                    else
                    {
                        e14Image.setColor(sf::Color(255, 255, 255));
                    }

                    if(e15Image.getGlobalBounds().contains(mousePosF))
                    {
                        e15Image.setColor(sf::Color(200, 255, 255));
                    }
                    else
                    {
                        e15Image.setColor(sf::Color(255, 255, 255));
                    }

                    if(e16Image.getGlobalBounds().contains(mousePosF))
                    {
                        e16Image.setColor(sf::Color(200, 255, 255));
                    }
                    else
                    {
                        e16Image.setColor(sf::Color(255, 255, 255));
                    }

                    if(e17Image.getGlobalBounds().contains(mousePosF))
                    {
                        e17Image.setColor(sf::Color(200, 255, 255));
                    }
                    else
                    {
                        e17Image.setColor(sf::Color(255, 255, 255));
                    }

                }
                break;

                case sf::Event::MouseButtonPressed:
                    {
                        sf::Vector2i mousePos = sf::Mouse::getPosition(window);
                        sf::Vector2f mousePosF (static_cast<float>(mousePos.x), static_cast<float>(mousePos.y));

                        if(e1Image.getGlobalBounds().contains(mousePosF))
                        {
                            if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Ambitions\\", &RegKey) == ERROR_SUCCESS)
                            {
                                system("reg\\1An.reg");
                                system("reg\\1Bn.reg");

                                cout << "Data is there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Ambitions\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data removed" << endl;
                                    (!e1.loadFromFile("resources/e1.png", sf::IntRect(0, 0, 194, 30)));
                                }
                            }
                            else
                            {
                                system("reg\\1A.reg");
                                system("reg\\1B.reg");

                                cout << "Data is not there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Ambitions\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data added" << endl;
                                    (!e1.loadFromFile("resources/e1.png", sf::IntRect(194, 0, 194, 30)));
                                }
                            }
                        }

                        if(e2Image.getGlobalBounds().contains(mousePosF))
                        {
                            if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Generations\\", &RegKey) == ERROR_SUCCESS)
                            {
                                system("reg\\2An.reg");
                                system("reg\\2Bn.reg");

                                cout << "Data is there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Generations\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data removed" << endl;
                                    (!e2.loadFromFile("resources/e2.png", sf::IntRect(0, 0, 194, 30)));
                                }
                            }
                            else
                            {
                                system("reg\\2A.reg");
                                system("reg\\2B.reg");

                                cout << "Data is not there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Generations\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data added" << endl;
                                    (!e2.loadFromFile("resources/e2.png", sf::IntRect(194, 0, 194, 30)));
                                }
                            }
                        }

                        if(e3Image.getGlobalBounds().contains(mousePosF))
                        {
                            if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 High-End Loft Stuff\\", &RegKey) == ERROR_SUCCESS)
                            {
                                system("reg\\3An.reg");
                                system("reg\\3Bn.reg");

                                cout << "Data is there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 High-End Loft Stuff\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data removed" << endl;
                                    (!e3.loadFromFile("resources/e3.png", sf::IntRect(0, 0, 194, 30)));
                                }
                            }
                            else
                            {
                                system("reg\\3A.reg");
                                system("reg\\3B.reg");

                                cout << "Data is not there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 High-End Loft Stuff\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data added" << endl;
                                    (!e3.loadFromFile("resources/e3.png", sf::IntRect(194, 0, 194, 30)));
                                }
                            }
                        }

                        if(e4Image.getGlobalBounds().contains(mousePosF))
                        {
                            if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Island Paradise\\", &RegKey) == ERROR_SUCCESS)
                            {
                                system("reg\\4An.reg");
                                system("reg\\4Bn.reg");
                                cout << "Data is there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Island Paradise\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data removed" << endl;
                                    (!e4.loadFromFile("resources/e4.png", sf::IntRect(0, 0, 194, 30)));
                                }
                            }
                            else
                            {
                                system("reg\\4A.reg");
                                system("reg\\4B.reg");

                                cout << "Data is not there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Island Paradise\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data added" << endl;
                                    (!e4.loadFromFile("resources/e4.png", sf::IntRect(194, 0, 194, 30)));
                                }
                            }
                        }

                        if(e5Image.getGlobalBounds().contains(mousePosF))
                        {
                            if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Late Night\\", &RegKey) == ERROR_SUCCESS)
                            {
                                system("reg\\5An.reg");
                                system("reg\\5Bn.reg");
                                cout << "Data is there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Late Night\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data removed" << endl;
                                    (!e5.loadFromFile("resources/e5.png", sf::IntRect(0, 0, 194, 30)));
                                }
                            }
                            else
                            {
                                system("reg\\5A.reg");
                                system("reg\\5B.reg");

                                cout << "Data is not there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Late Night\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data added" << endl;
                                    (!e5.loadFromFile("resources/e5.png", sf::IntRect(194, 0, 194, 30)));
                                }
                            }
                        }

                        if(e6Image.getGlobalBounds().contains(mousePosF))
                        {
                            if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Master Suite Stuff\\", &RegKey) == ERROR_SUCCESS)
                            {
                                system("reg\\6An.reg");
                                system("reg\\6Bn.reg");

                                cout << "Data is there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Master Suite Stuff\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data removed" << endl;
                                    (!e6.loadFromFile("resources/e6.png", sf::IntRect(0, 0, 194, 30)));
                                }
                            }
                            else
                            {
                                system("reg\\6A.reg");
                                system("reg\\6B.reg");

                                cout << "Data is not there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Master Suite Stuff\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data added" << endl;
                                    (!e6.loadFromFile("resources/e6.png", sf::IntRect(194, 0, 194, 30)));
                                }
                            }
                        }

                        if(e7Image.getGlobalBounds().contains(mousePosF))
                        {
                            if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Outdoor Living Stuff\\", &RegKey) == ERROR_SUCCESS)
                            {
                                system("reg\\7An.reg");
                                system("reg\\7Bn.reg");

                                cout << "Data is there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Outdoor Living Stuff\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data removed" << endl;
                                    (!e7.loadFromFile("resources/e7.png", sf::IntRect(0, 0, 194, 30)));
                                }
                            }
                            else
                            {
                                system("reg\\7A.reg");
                                system("reg\\7B.reg");

                                cout << "Data is not there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Outdoor Living Stuff\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data added" << endl;
                                    (!e7.loadFromFile("resources/e7.png", sf::IntRect(194, 0, 194, 30)));
                                }
                            }
                        }

                        if(e8Image.getGlobalBounds().contains(mousePosF))
                        {
                            if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Pets\\", &RegKey) == ERROR_SUCCESS)
                            {
                                system("reg\\8An.reg");
                                system("reg\\8Bn.reg");

                                cout << "Data is there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Pets\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data removed" << endl;
                                    (!e8.loadFromFile("resources/e8.png", sf::IntRect(0, 0, 194, 30)));
                                }
                            }
                            else
                            {
                                system("reg\\8A.reg");
                                system("reg\\8B.reg");

                                cout << "Data is not there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Pets\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data added" << endl;
                                    (!e8.loadFromFile("resources/e8.png", sf::IntRect(194, 0, 194, 30)));
                                }
                            }
                        }

                        if(e9Image.getGlobalBounds().contains(mousePosF))
                        {
                            if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Seasons\\", &RegKey) == ERROR_SUCCESS)
                            {
                                system("reg\\9An.reg");
                                system("reg\\9Bn.reg");

                                cout << "Data is there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Seasons\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data removed" << endl;
                                    (!e9.loadFromFile("resources/e9.png", sf::IntRect(0, 0, 194, 30)));
                                }
                            }
                            else
                            {
                                system("reg\\9A.reg");
                                system("reg\\9B.reg");

                                cout << "Data is not there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Seasons\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data added" << endl;
                                    (!e9.loadFromFile("resources/e9.png", sf::IntRect(194, 0, 194, 30)));
                                }
                            }
                        }

                        if(e10Image.getGlobalBounds().contains(mousePosF))
                        {
                            if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Showtime\\", &RegKey) == ERROR_SUCCESS)
                            {
                                system("reg\\10An.reg");
                                system("reg\\10Bn.reg");

                                cout << "Data is there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Showtime\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data removed" << endl;
                                    (!e10.loadFromFile("resources/e10.png", sf::IntRect(0, 0, 194, 30)));
                                }
                            }
                            else
                            {
                                system("reg\\10A.reg");
                                system("reg\\10B.reg");

                                cout << "Data is not there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Showtime\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data added" << endl;
                                    (!e10.loadFromFile("resources/e10.png", sf::IntRect(194, 0, 194, 30)));
                                }
                            }
                        }

                        if(e11Image.getGlobalBounds().contains(mousePosF))
                        {
                            if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Supernatural\\", &RegKey) == ERROR_SUCCESS)
                            {
                                system("reg\\11An.reg");
                                system("reg\\11Bn.reg");
                                cout << "Data is there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Supernatural\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data removed" << endl;
                                    (!e11.loadFromFile("resources/e11.png", sf::IntRect(0, 0, 194, 30)));
                                }
                            }
                            else
                            {
                                system("reg\\11A.reg");
                                system("reg\\11B.reg");

                                cout << "Data is not there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Supernatural\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data added" << endl;
                                    (!e11.loadFromFile("resources/e11.png", sf::IntRect(194, 0, 194, 30)));
                                }
                            }
                        }

                        if(e12Image.getGlobalBounds().contains(mousePosF))
                        {
                            if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Town Life Stuff\\", &RegKey) == ERROR_SUCCESS)
                            {
                                system("reg\\12An.reg");
                                system("reg\\12Bn.reg");

                                cout << "Data is there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Town Life Stuff\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data removed" << endl;
                                    (!e12.loadFromFile("resources/e12.png", sf::IntRect(0, 0, 194, 30)));
                                }
                            }
                            else
                            {
                                system("reg\\12A.reg");
                                system("reg\\12B.reg");

                                cout << "Data is not there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 Town Life Stuff\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data added" << endl;
                                    (!e12.loadFromFile("resources/e12.png", sf::IntRect(194, 0, 194, 30)));
                                }
                            }
                        }

                        if(e13Image.getGlobalBounds().contains(mousePosF))
                        {
                            if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 University Life\\", &RegKey) == ERROR_SUCCESS)
                            {
                                system("reg\\13An.reg");
                                system("reg\\13Bn.reg");

                                cout << "Data is there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 University Life\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data removed" << endl;
                                    (!e13.loadFromFile("resources/e13.png", sf::IntRect(0, 0, 194, 30)));
                                }
                            }
                            else
                            {
                                system("reg\\13A.reg");
                                system("reg\\13B.reg");

                                cout << "Data is not there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 University Life\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data added" << endl;
                                    (!e13.loadFromFile("resources/e13.png", sf::IntRect(194, 0, 194, 30)));
                                }
                            }
                        }

                        if(e14Image.getGlobalBounds().contains(mousePosF))
                        {
                            if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 World Adventures\\", &RegKey) == ERROR_SUCCESS)
                            {
                                system("reg\\14An.reg");
                                system("reg\\14Bn.reg");

                                cout << "Data is there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 World Adventures\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data removed" << endl;
                                    (!e14.loadFromFile("resources/e14.png", sf::IntRect(0, 0, 194, 30)));
                                }
                            }
                            else
                            {
                                system("reg\\14A.reg");
                                system("reg\\14B.reg");

                                cout << "Data is not there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 World Adventures\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data added" << endl;
                                    (!e14.loadFromFile("resources/e14.png", sf::IntRect(194, 0, 194, 30)));
                                }

                            }
                        }

                        if(e15Image.getGlobalBounds().contains(mousePosF))
                        {
                            if (RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 70s 80s & 90s Stuff\\", &RegKey) == ERROR_SUCCESS)
                            {
                                system("reg\\15An.reg");
                                system("reg\\15Bn.reg");

                                cout << "Data is there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 70s 80s & 90s Stuff\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data removed" << endl;
                                    (!e15.loadFromFile("resources/e15.png", sf::IntRect(0, 0, 194, 30)));

                                }
                            }
                            else
                            {
                                system("reg\\15A.reg");
                                system("reg\\15B.reg");

                                cout << "Data is not there" << endl;

                                if(RegOpenKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\WOW6432Node\\Sims\\The Sims 3 70s 80s & 90s Stuff\\", &RegKey) == ERROR_SUCCESS)
                                {
                                    cout << "Data added" << endl;
                                    (!e15.loadFromFile("resources/e15.png", sf::IntRect(194, 0, 194, 30)));

                                }
                            }
                        }

                        if(e16Image.getGlobalBounds().contains(mousePosF))
                        {
                                system("reg\\16A.reg");
                                system("reg\\16B.reg");
                                (!e1.loadFromFile("resources/e1.png", sf::IntRect(0, 0, 194, 30)));
                                (!e2.loadFromFile("resources/e2.png", sf::IntRect(0, 0, 194, 30)));
                                (!e3.loadFromFile("resources/e3.png", sf::IntRect(0, 0, 194, 30)));
                                (!e4.loadFromFile("resources/e4.png", sf::IntRect(0, 0, 194, 30)));
                                (!e5.loadFromFile("resources/e5.png", sf::IntRect(0, 0, 194, 30)));
                                (!e6.loadFromFile("resources/e6.png", sf::IntRect(0, 0, 194, 30)));
                                (!e7.loadFromFile("resources/e7.png", sf::IntRect(0, 0, 194, 30)));
                                (!e8.loadFromFile("resources/e8.png", sf::IntRect(0, 0, 194, 30)));
                                (!e9.loadFromFile("resources/e9.png", sf::IntRect(0, 0, 194, 30)));
                                (!e10.loadFromFile("resources/e10.png", sf::IntRect(0, 0, 194, 30)));
                                (!e11.loadFromFile("resources/e11.png", sf::IntRect(0, 0, 194, 30)));
                                (!e12.loadFromFile("resources/e12.png", sf::IntRect(0, 0, 194, 30)));
                                (!e13.loadFromFile("resources/e13.png", sf::IntRect(0, 0, 194, 30)));
                                (!e14.loadFromFile("resources/e14.png", sf::IntRect(0, 0, 194, 30)));
                                (!e15.loadFromFile("resources/e15.png", sf::IntRect(0, 0, 194, 30)));
                        }
                        if(e17Image.getGlobalBounds().contains(mousePosF))
                        {
                                return 0;
                        }

                    }
                    break;


            }
        }

        window.clear();
        window.setFramerateLimit(30);
        window.draw(backgroundImage);
        window.draw(e1Image);
        window.draw(e2Image);
        window.draw(e3Image);
        window.draw(e4Image);
        window.draw(e5Image);
        window.draw(e6Image);
        window.draw(e7Image);
        window.draw(e8Image);
        window.draw(e9Image);
        window.draw(e10Image);
        window.draw(e11Image);
        window.draw(e12Image);
        window.draw(e13Image);
        window.draw(e14Image);
        window.draw(e15Image);
        window.draw(e16Image);
        window.draw(e17Image);
        window.display();
    }

    return 0;
}
